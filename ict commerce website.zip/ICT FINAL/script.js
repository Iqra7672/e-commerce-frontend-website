document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    const formMessage = document.getElementById('formMessage');

    // Simple validation
    if (!name || !email || !message) {
        formMessage.innerText = 'Please fill in all fields.';
        formMessage.style.color = 'red';
        return;
    }

    // More detailed email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        formMessage.innerText = 'Please enter a valid email address.';
        formMessage.style.color = 'red';
        return;
    }

   
});
